# [Compress HTML in Jekyll][site]

[![Build Status](https://travis-ci.org/penibelst/jekyll-compress-html.svg?branch=master)](https://travis-ci.org/penibelst/jekyll-compress-html)

* [Documentation][site]
* [Download](https://github.com/penibelst/jekyll-compress-html/releases/latest)

[site]: http://jch.penibelst.de/
